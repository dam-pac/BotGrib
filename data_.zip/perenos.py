﻿# -*- coding: utf-8 -*-
from platform import libc_ver
import db.db_work
import pickle
import os

def load_data(user):
    try:
        with open(f'{user}.ud', 'rb') as file:
            data = pickle.load(file)
            return data
    except:
        print(f"not found {user}")
        return 0
def dop_data(user_id, what):
    if what == 'lives':
        try:
            with open('lives.list', 'rb') as file:
                dop_data = pickle.load(file)
        except:
            with open('lives.list', 'wb') as file:
                file_write = [[user_id, 100]]
                pickle.dump(file_write, file)
                return 'no'
        list_len = len(dop_data)
        i = 0
        for sub_list in dop_data:
            if user_id in sub_list:
                return sub_list[1]
            i += 1
            if i == list_len:
                data = [user_id, 100]
                dop_data.append(data)
                with open('lives.list', 'wb') as file:
                    pickle.dump(dop_data, file)
                for sub_list in dop_data:
                    if user_id in sub_list:
                        return sub_list[1]
    elif what == 'timely':
        try:
            with open('timely.list', 'rb') as file:
                dop_data = pickle.load(file)
        except:
            with open('timely.list', 'wb') as file:
                file_write = [[user_id, 1]]
                pickle.dump(file_write, file)
                return 'no'
        list_len = len(dop_data)
        i = 0
        for sub_list in dop_data:
            if user_id in sub_list:
                return sub_list[1]
            i += 1
            if i == list_len:
                data = [user_id, 1]
                dop_data.append(data)
                with open('timely.list', 'wb') as file:
                    pickle.dump(dop_data, file)
                for sub_list in dop_data:
                    if user_id in sub_list:
                        return sub_list[1]
    elif what == 'exp_buff':
        try:
            with open('exp.list', 'rb') as file:
                dop_data = pickle.load(file)
        except:
            with open('exp.list', 'wb') as file:
                file_write = [[user_id, 1]]
                pickle.dump(file_write, file)
                return 'no'
        list_len = len(dop_data)
        i = 0
        for sub_list in dop_data:
            if user_id in sub_list:
                return sub_list[1]
            i += 1
            if i == list_len:
                data = [user_id, 1]
                dop_data.append(data)
                with open('exp.list', 'wb') as file:
                    pickle.dump(dop_data, file)
                for sub_list in dop_data:
                    if user_id in sub_list:
                        return sub_list[1]
    elif what == 'kurs':
        try:
            with open('kurs.list', 'rb') as file:
                dop_data = pickle.load(file)
        except:
            with open('kurs.list', 'wb') as file:
                file_write = [[user_id, 1]]
                pickle.dump(file_write, file)
                return 'no'
        list_len = len(dop_data)
        i = 0
        for sub_list in dop_data:
            if user_id in sub_list:
                return sub_list[1]
            i += 1
            if i == list_len:
                data = [user_id, 1]
                dop_data.append(data)
                with open('kurs.list', 'wb') as file:
                    pickle.dump(dop_data, file)
                for sub_list in dop_data:
                    if user_id in sub_list:
                        return sub_list[1]
    else:
        pass
def is_data(user):
    data = load_data(user)
    type_data = isinstance(data, dict)
    while type_data == False:
        data = load_data(user)
        type_data = isinstance(data, dict)
    return data
def get_data(data, what):
    if what == "user":
        user = data.get("user")
        return user
    elif what == "experience":
        experience = data.get("experience")
        return experience
    elif what == 'level':
        level = data.get("level")
        return level
    elif what == "balance":
        balance = data.get("balance")
        return balance
    elif what == "timely_date":
        timely_date = data.get("timely_date")
        return timely_date
    else:
        return 0

files = os.listdir()

for item in files:
    name, extension = os.path.splitext(item)
    try:
        name = int(name)
        data = load_data(name)
        if data != 0:
            data = is_data(name)
            print("ЕСТЬ ДАТА!")
            user_name = get_data(data, "user")
            experience = get_data(data, "experience")
            level = get_data(data, "level")
            balance = get_data(data, "balance")
            lives = dop_data(name, "lives")
            timely = dop_data(name, "timely")
            exp_buff = dop_data(name, "exp_buff")
            kurs = dop_data(name, "kurs")
            check = db.db_work.get("user_id", name, user_name)
            if check == name:
                db.db_work.upd("user_name", user_name, name)
                db.db_work.upd("experience", experience, name)
                db.db_work.upd("level", level, name)
                db.db_work.upd("balance", balance, name)
                db.db_work.upd("lives", lives, name)
                db.db_work.upd("timely", timely, name)
                db.db_work.upd("exp_buff", exp_buff, name)
                db.db_work.upd("kurs", kurs, name)
                print("БД ЗАПИСАНО, ПЕРЕНОС УСПЕХ")
        elif data == 0:
            pass
        else:
            print("Что-то не так, прекрати код!!!")
    except:
        print(f"Это файл {name}")
    